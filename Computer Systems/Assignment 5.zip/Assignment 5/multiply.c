/*
 * Author: Declan McGranahan - mcgranad@bc.edu
*/

// Function that takes two longs and returns there multiplication
long multiply(long x, long y) {
    return x * y;
}